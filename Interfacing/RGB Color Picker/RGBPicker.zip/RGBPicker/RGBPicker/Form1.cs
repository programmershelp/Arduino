﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;

namespace RGBPicker
{
    public partial class Form1 : Form
    {
        SerialPort port = new SerialPort("COM5", 9600);

        // Initialize the default color to black
        private Color defaultColor = Color.FromArgb(0, 0, 0);
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            port.Open();
            this.SetRGBColor(defaultColor);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            port.Close();
        }

        private void panel1_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                SetRGBColor(colorDialog1.Color);
            }
        }

        private void SetRGBColor(Color color)
        {
            // Update color
            panel1.BackColor = color;
            // send color to Arduino
            port.Write(new[] { color.R, color.G, color.B }, 0, 3);
        }
    }
}
