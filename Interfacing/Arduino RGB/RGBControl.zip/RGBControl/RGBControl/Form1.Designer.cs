﻿namespace RGBControl
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnRedon = new System.Windows.Forms.Button();
            this.btnRedoff = new System.Windows.Forms.Button();
            this.btnGreenoff = new System.Windows.Forms.Button();
            this.btnGreenon = new System.Windows.Forms.Button();
            this.btnBlueoff = new System.Windows.Forms.Button();
            this.btnBlueon = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.SuspendLayout();
            // 
            // btnRedon
            // 
            this.btnRedon.Location = new System.Drawing.Point(12, 12);
            this.btnRedon.Name = "btnRedon";
            this.btnRedon.Size = new System.Drawing.Size(157, 67);
            this.btnRedon.TabIndex = 0;
            this.btnRedon.Text = "RED On";
            this.btnRedon.UseVisualStyleBackColor = true;
            this.btnRedon.Click += new System.EventHandler(this.btnRedon_Click);
            // 
            // btnRedoff
            // 
            this.btnRedoff.Location = new System.Drawing.Point(185, 12);
            this.btnRedoff.Name = "btnRedoff";
            this.btnRedoff.Size = new System.Drawing.Size(157, 67);
            this.btnRedoff.TabIndex = 1;
            this.btnRedoff.Text = "RED Off";
            this.btnRedoff.UseVisualStyleBackColor = true;
            this.btnRedoff.Click += new System.EventHandler(this.btnRedoff_Click);
            // 
            // btnGreenoff
            // 
            this.btnGreenoff.Location = new System.Drawing.Point(185, 99);
            this.btnGreenoff.Name = "btnGreenoff";
            this.btnGreenoff.Size = new System.Drawing.Size(157, 67);
            this.btnGreenoff.TabIndex = 3;
            this.btnGreenoff.Text = "GREEN Off";
            this.btnGreenoff.UseVisualStyleBackColor = true;
            this.btnGreenoff.Click += new System.EventHandler(this.btnGreenoff_Click);
            // 
            // btnGreenon
            // 
            this.btnGreenon.Location = new System.Drawing.Point(12, 99);
            this.btnGreenon.Name = "btnGreenon";
            this.btnGreenon.Size = new System.Drawing.Size(157, 67);
            this.btnGreenon.TabIndex = 2;
            this.btnGreenon.Text = "GREEN On";
            this.btnGreenon.UseVisualStyleBackColor = true;
            this.btnGreenon.Click += new System.EventHandler(this.btnGreenon_Click);
            // 
            // btnBlueoff
            // 
            this.btnBlueoff.Location = new System.Drawing.Point(185, 184);
            this.btnBlueoff.Name = "btnBlueoff";
            this.btnBlueoff.Size = new System.Drawing.Size(157, 67);
            this.btnBlueoff.TabIndex = 5;
            this.btnBlueoff.Text = "BLUE Off";
            this.btnBlueoff.UseVisualStyleBackColor = true;
            this.btnBlueoff.Click += new System.EventHandler(this.btnBlueoff_Click);
            // 
            // btnBlueon
            // 
            this.btnBlueon.Location = new System.Drawing.Point(12, 184);
            this.btnBlueon.Name = "btnBlueon";
            this.btnBlueon.Size = new System.Drawing.Size(157, 67);
            this.btnBlueon.TabIndex = 4;
            this.btnBlueon.Text = "BLUE On";
            this.btnBlueon.UseVisualStyleBackColor = true;
            this.btnBlueon.Click += new System.EventHandler(this.btnBlueon_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(357, 274);
            this.Controls.Add(this.btnBlueoff);
            this.Controls.Add(this.btnBlueon);
            this.Controls.Add(this.btnGreenoff);
            this.Controls.Add(this.btnGreenon);
            this.Controls.Add(this.btnRedoff);
            this.Controls.Add(this.btnRedon);
            this.Name = "Form1";
            this.Text = "RGB Control";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnRedon;
        private System.Windows.Forms.Button btnRedoff;
        private System.Windows.Forms.Button btnGreenoff;
        private System.Windows.Forms.Button btnGreenon;
        private System.Windows.Forms.Button btnBlueoff;
        private System.Windows.Forms.Button btnBlueon;
        private System.IO.Ports.SerialPort serialPort1;
    }
}

